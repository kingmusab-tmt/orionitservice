(()=>{var e={};e.id=870,e.ids=[870],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},37366:e=>{"use strict";e.exports=require("dns")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},65639:(e,r,s)=>{"use strict";s.r(r),s.d(r,{patchFetch:()=>g,routeModule:()=>c,serverHooks:()=>d,workAsyncStorage:()=>l,workUnitAsyncStorage:()=>m});var t={};s.r(t),s.d(t,{POST:()=>p});var o=s(96559),n=s(48088),i=s(37719),a=s(32190),u=s(49526);async function p(e){try{var r,s;let t=e.headers.get("content-type");if(!t||!t.includes("application/json"))return a.NextResponse.json({error:"Invalid content type. Please use application/json"},{status:400});let o=await e.json(),n=function(e){var r;let s=[];return e.name&&"string"==typeof e.name&&0!==e.name.trim().length||s.push("Name is required and must be a non-empty string"),e.email&&"string"==typeof e.email&&(r=e.email,/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(r))||s.push("Valid email is required"),e.message&&"string"==typeof e.message&&0!==e.message.trim().length||s.push("Message is required and must be a non-empty string"),e.phone&&"string"!=typeof e.phone&&s.push("Phone must be a string if provided"),s}(o);if(n.length>0)return a.NextResponse.json({errors:n},{status:400});let i=["SMTP_HOST","SMTP_PORT","SMTP_SECURE","SMTP_USER","SMTP_PASSWORD","SMTP_INFO_EMAIL","SMTP_SUPPORT_EMAIL"].filter(e=>!process.env[e]);if(i.length>0)return console.error("Missing environment variables:",i),a.NextResponse.json({error:"Server configuration error"},{status:500});let p=u.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT),secure:"true"===process.env.SMTP_SECURE,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASSWORD}}),c={from:`"Contact Form" <${process.env.SMTP_INFO_EMAIL}>`,to:process.env.SMTP_CONTACT_EMAIL,subject:`New Contact Request from ${o.name}`,text:(r=o,`
    Name: ${r.name}
    Email: ${r.email}
    Phone: ${r.phone||"Not provided"}
    
    Message:
    ${r.message}
  `),html:(s=o,`
    <h2>New Contact Request</h2>
    <p><strong>From:</strong> ${s.name}</p>
    <p><strong>Email:</strong> ${s.email}</p>
    <p><strong>Phone:</strong> ${s.phone||"Not provided"}</p>
    
    <h3>Message</h3>
    <p>${s.message}</p>
  `)},l={from:`"Orion IT Support" <${process.env.SMTP_SUPPORT_EMAIL}>`,to:o.email,subject:"We Received Your Request",html:`
        <h2>Dear ${o.name}, Thank you for contacting Orion IT!</h2>
        <p>We've received your request and one of our experts will contact you within 24 hours.</p>
        <p>Here's a summary of your request:</p>
        <ul>
        <li><strong>Message:</strong> ${o.message||"No additional message"}</li>
        </ul>
        <p>If you have any immediate questions, please reply to this email or call us at +1 702-800-9182.</p>
        <br/>
        <p>Best regards,</p>
        <p>The Orion IT Team</p>
      `};return await Promise.all([await p.sendMail(c),p.sendMail(l)]),a.NextResponse.json({success:!0,message:"Contact request submitted successfully"},{status:200})}catch(e){return console.error("Error processing request:",e),a.NextResponse.json({error:"Internal server error",details:e instanceof Error?e.message:"Unknown error"},{status:500})}}let c=new o.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/contactus/route",pathname:"/api/contactus",filename:"route",bundlePath:"app/api/contactus/route"},resolvedPagePath:"C:\\laptop\\orionitservice\\orionitservice\\app\\api\\contactus\\route.ts",nextConfigOutput:"",userland:t}),{workAsyncStorage:l,workUnitAsyncStorage:m,serverHooks:d}=c;function g(){return(0,i.patchFetch)({workAsyncStorage:l,workUnitAsyncStorage:m})}},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},81630:e=>{"use strict";e.exports=require("http")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var r=require("../../../webpack-runtime.js");r.C(e);var s=e=>r(r.s=e),t=r.X(0,[447,580,526],()=>s(65639));module.exports=t})();