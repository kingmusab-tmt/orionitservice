(()=>{var e={};e.id=110,e.ids=[110],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},37366:e=>{"use strict";e.exports=require("dns")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},47374:(e,s,r)=>{"use strict";r.r(s),r.d(s,{patchFetch:()=>g,routeModule:()=>c,serverHooks:()=>d,workAsyncStorage:()=>l,workUnitAsyncStorage:()=>m});var t={};r.r(t),r.d(t,{POST:()=>p});var o=r(96559),n=r(48088),i=r(37719),a=r(32190),u=r(49526);async function p(e){try{let s=await e.json();if(!s.name||!s.company||!s.email||!s.service||!s.employees)return a.NextResponse.json({message:"Missing required fields"},{status:400});let r=u.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT),secure:!0,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASSWORD}}),t={from:`"Orion IT Consultations" <${process.env.SMTP_CONSULTATION_EMAIL}>`,to:process.env.SMTP_SUPPORT_EMAIL,subject:`New Consultation Request from ${s.name}`,html:`
        <h2>New Consultation Request</h2>
        <p><strong>Name:</strong> ${s.name}</p>
        <p><strong>Company:</strong> ${s.company}</p>
        <p><strong>Email:</strong> ${s.email}</p>
        <p><strong>Phone:</strong> ${s.phone||"Not provided"}</p>
        <p><strong>Service Interest:</strong> ${s.service}</p>
        <p><strong>Company Size:</strong> ${s.employees}</p>
        <p><strong>Message:</strong> ${s.message||"No additional message"}</p>
        <br/>
        <p>This request was submitted through the Orion IT website consultation form.</p>
      `},o={from:`"Orion IT Support" <${process.env.SMTP_CONSULTATION_EMAIL}>`,to:s.email,subject:"We Received Your Consultation Request",html:`
        <h2>Thank you for contacting Orion IT!</h2>
        <p>We've received your consultation request and one of our experts will contact you within 24 hours.</p>
        <p>Here's a summary of your request:</p>
        <ul>
        <li><strong>Name:</strong> ${s.name}</li>
        <li><strong>Company:</strong> ${s.company}</li>
        <li><strong>Email:</strong> ${s.email}</li>
        <li><strong>Phone:</strong> ${s.phone||"Not provided"}</li>
        <li><strong>Service Interest:</strong> ${s.service}</li>
        <li><strong>Company Size:</strong> ${s.employees}</li>
        <li><strong>Message:</strong> ${s.message||"No additional message"}</li>
        </ul>
        <p>If you have any immediate questions, please reply to this email or call us at +1 702-800-9182.</p>
        <br/>
        <p>Best regards,</p>
        <p>The Orion IT Team</p>
      `};return await Promise.all([r.sendMail(t),r.sendMail(o)]),a.NextResponse.json({message:"Consultation request sent successfully"},{status:200})}catch(e){return console.error("Error sending consultation request:",e),a.NextResponse.json({message:"Error sending consultation request"},{status:500})}}let c=new o.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/send-consultation/route",pathname:"/api/send-consultation",filename:"route",bundlePath:"app/api/send-consultation/route"},resolvedPagePath:"C:\\laptop\\orionitservice\\orionitservice\\app\\api\\send-consultation\\route.ts",nextConfigOutput:"",userland:t}),{workAsyncStorage:l,workUnitAsyncStorage:m,serverHooks:d}=c;function g(){return(0,i.patchFetch)({workAsyncStorage:l,workUnitAsyncStorage:m})}},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},81630:e=>{"use strict";e.exports=require("http")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var s=require("../../../webpack-runtime.js");s.C(e);var r=e=>s(s.s=e),t=s.X(0,[447,580,526],()=>r(47374));module.exports=t})();