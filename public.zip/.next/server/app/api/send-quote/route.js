(()=>{var e={};e.id=375,e.ids=[375],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},11330:(e,r,t)=>{"use strict";t.r(r),t.d(r,{patchFetch:()=>g,routeModule:()=>c,serverHooks:()=>m,workAsyncStorage:()=>l,workUnitAsyncStorage:()=>d});var s={};t.r(s),t.d(s,{POST:()=>u});var o=t(96559),i=t(48088),n=t(37719),p=t(32190),a=t(49526);async function u(e){try{var r,t,s,o,i,n;let u=e.headers.get("content-type");if(!u||!u.includes("application/json"))return p.NextResponse.json({error:"Invalid content type. Please use application/json"},{status:400});let c=await e.json(),l=function(e){var r;let t=[];if(e.name&&"string"==typeof e.name&&0!==e.name.trim().length||t.push("Name is required and must be a non-empty string"),e.email&&"string"==typeof e.email&&(r=e.email,/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(r))||t.push("Valid email is required"),e.company&&"string"==typeof e.company&&0!==e.company.trim().length||t.push("Company name is required and must be a non-empty string"),e.services&&"object"==typeof e.services){let r=["cybersecurity","networking","manageit","backup","other"],s=Object.keys(e.services);for(let o of(0===s.length&&t.push("At least one service must be selected"),s))r.includes(o)?"boolean"!=typeof e.services[o]&&t.push(`Service value for ${o} must be boolean`):t.push(`Invalid service key: ${o}`);e.services.other&&(!e.otherService||"string"!=typeof e.otherService||0===e.otherService.trim().length)&&t.push('Other service description is required when "other" is selected')}else t.push("Services selection is required");return e.phone&&"string"!=typeof e.phone&&t.push("Phone must be a string if provided"),e.employees&&"string"!=typeof e.employees&&t.push("Employees must be a string if provided"),e.timeline&&"string"!=typeof e.timeline&&t.push("Timeline must be a string if provided"),e.budget&&"string"!=typeof e.budget&&t.push("Budget must be a string if provided"),e.message&&"string"!=typeof e.message&&t.push("Message must be a string if provided"),t}(c);if(l.length>0)return p.NextResponse.json({errors:l},{status:400});let d=["SMTP_HOST","SMTP_PORT","SMTP_SECURE","SMTP_USER","SMTP_PASSWORD","SMTP_INFO_EMAIL","SMTP_SUPPORT_EMAIL"].filter(e=>!process.env[e]);if(d.length>0)return console.error("Missing environment variables:",d),p.NextResponse.json({error:"Server configuration error"},{status:500});let m=a.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT),secure:"true"===process.env.SMTP_SECURE,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASSWORD}}),g=(r=c.services,t=c.otherService,Object.entries(r).filter(([e,r])=>r).map(([e])=>{switch(e){case"cybersecurity":return"Cybersecurity Training";case"networking":return"Network Solutions";case"manageit":return"Managed IT Services";case"backup":return"Data Backup & Recovery";case"other":return`Other: ${t||"Not specified"}`;default:return e}}).join(", ")),h={from:`"Quote Form" <${process.env.SMTP_CONTACT_EMAIL}>`,to:process.env.SMTP_SUPPORT_EMAIL,subject:`New Quote Request from ${c.company}`,text:(s=c,o=g,`
    Name: ${s.name}
    Company: ${s.company}
    Email: ${s.email}
    Phone: ${s.phone||"Not provided"}
    Employees: ${s.employees||"Not specified"}
    
    Services Needed: ${o}
    Timeline: ${s.timeline||"Not specified"}
    Budget: ${s.budget||"Not specified"}
    
    Additional Information:
    ${s.message||"None"}
  `),html:(i=c,n=g,`
    <h2>New Quote Request</h2>
    <p><strong>From:</strong> ${i.name} (${i.company})</p>
    <p><strong>Email:</strong> ${i.email}</p>
    <p><strong>Phone:</strong> ${i.phone||"Not provided"}</p>
    <p><strong>Company Size:</strong> ${i.employees||"Not specified"}</p>
    
    <h3>Services Requested</h3>
    <p>${n.replace(/, /g,"<br>")}</p>
    
    <p><strong>Timeline:</strong> ${i.timeline||"Not specified"}</p>
    <p><strong>Budget:</strong> ${i.budget||"Not specified"}</p>
    
    <h3>Additional Information</h3>
    <p>${i.message||"None"}</p>
  `)},v={from:`"Orion IT Support" <${process.env.SMTP_SUPPORT_EMAIL}>`,to:c.email,subject:"We Received Your Request for a Quote",html:`
        <h2>Dear ${c.name}, Thank you for contacting Orion IT!</h2>
        <p>We've received your request for a Quote and one of our experts will get back to you within 24 hours.</p>
        <p>Here's a summary of your request:</p>
        <ul>
          <li><strong>Name:</strong> ${c.name}</li>
          <li><strong>Company:</strong> ${c.company}</li>
          <li><strong>Email:</strong> ${c.email}</li>
          <li><strong>Phone:</strong> ${c.phone||"Not provided"}</li>
          <li><strong>Employees:</strong> ${c.employees||"Not specified"}</li>
          <li><strong>Services Needed:</strong> ${g}</li>
          <li><strong>Timeline:</strong> ${c.timeline||"Not specified"}</li>
          <li><strong>Budget:</strong> ${c.budget||"Not specified"}</li>
          <li><strong>Message:</strong> ${c.message||"No additional message"}</li>
        </ul>
        <p>If you have any immediate questions, please reply to this email or call us at +1 702-800-9182.</p> 
      `};return await Promise.all([await m.sendMail(h),m.sendMail(v)]),p.NextResponse.json({success:!0,message:"Quote request submitted successfully"},{status:200})}catch(e){return console.error("Error processing request:",e),p.NextResponse.json({error:"Internal server error",details:e instanceof Error?e.message:"Unknown error"},{status:500})}}let c=new o.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/send-quote/route",pathname:"/api/send-quote",filename:"route",bundlePath:"app/api/send-quote/route"},resolvedPagePath:"C:\\laptop\\orionitservice\\orionitservice\\app\\api\\send-quote\\route.ts",nextConfigOutput:"",userland:s}),{workAsyncStorage:l,workUnitAsyncStorage:d,serverHooks:m}=c;function g(){return(0,n.patchFetch)({workAsyncStorage:l,workUnitAsyncStorage:d})}},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},37366:e=>{"use strict";e.exports=require("dns")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},81630:e=>{"use strict";e.exports=require("http")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var r=require("../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),s=r.X(0,[447,580,526],()=>t(11330));module.exports=s})();